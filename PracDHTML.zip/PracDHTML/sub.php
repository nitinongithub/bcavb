<?php
    echo $_POST['txtName'];
?>